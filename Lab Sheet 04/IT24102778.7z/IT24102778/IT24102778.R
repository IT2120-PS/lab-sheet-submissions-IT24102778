setwd("C:\\Users\\IT24102778\\Desktop\\IT24102778")
getwd()

data <- read.table("DATA 4.txt", header=TRUE, sep=" ")
fix(data)
attach(data)

boxplot(X1, main = "Box plot for Team Attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for Team Salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)

hist(X1, ylab = "Frequency", xlab = "Team Attendance", main = "Histogram for Team Attendance")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)


median(X1)
median(X2)
median(X3)


sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)
quantile(X1)


quantile(X1)[2]
quantile(X1)[4]


IQR(X1)
IQR(X2)
IQR(X3)


get.mode <- function(y){
  counts <- table(y)
  names(counts[counts == max(counts)])
}

get.mode(X3)

table(X3)y

max(counts)

counts[counts == max(counts)]

names(counts[counts == max(counts)])

#exercise
#1
branch_data <- read.table("Exercise.txt",header=TRUE,sep=",")

#2
attach(branch_data)
for(col in names(branch_data)){
  print(paste(col,":",class(branch_data[[col]])))
}
#Branch: Nominal
#Sales: Nominal/Ratio
#Advertising:Nominal/Ratio
#Years:Nominal/Ratio

#3
boxplot(branch_data$Sales_X1, Main="Sales",outline=TRUE, outpch=8, horizontal=TRUE,xlab="Sales")
hist(branch_data$Sales_X1, Main="Sales",outline=TRUE,outpch=8, horizontal=TRUE)

#4
summary(Advertising_X2)
IQR(Advertising_X2)

#5
get.outlier <-function(x){
  q1<-quantile(x)[2]
  q3<-quantile(x)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers =", paste(sort(x[x<lb | x>ub]),collapse=",")))
}
get.outlier(Years_X3)
